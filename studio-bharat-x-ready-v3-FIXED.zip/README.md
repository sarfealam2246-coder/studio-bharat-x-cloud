# STUDIO BHARAT X — VEDA Phone Agent

Flagship mobile-first creator studio with **real Android phone control** via Accessibility Service + Capacitor native plugin.

## What was fixed (v3 ready)

Previously the Phone Agent only **simulated** actions in the browser because:

1. Capacitor native plugin (`VedaAgent`) was never registered in the APK build.
2. `android-native/*.kt` files were never copied into the Capacitor Android project.
3. AccessibilityService was never declared in `AndroidManifest.xml`.

**This ZIP fixes all of the above.**

### Real control now available in APK

| Action | How |
|--------|-----|
| Open any app | by name (YouTube, WhatsApp, Facebook…) |
| Home / Back / Recents | global system actions |
| Swipe up / down | gesture via Accessibility |
| Read screen text | walks AccessibilityNode tree |
| Click by text | finds & clicks matching UI element |
| Tap at % position | coordinate tap |
| Brightness | system setting |
| Top Capsule overlay | floating "VEDA ● Live" pill |

## Build real APK (GitHub Actions)

1. Push this repo to GitHub.
2. Go to **Actions → Build STUDIO BHARAT X APK → Run workflow**.
3. Download the debug APK artifact.
4. Install on Android phone.

### First-time setup on phone (required once)

1. Open the app.
2. When prompted, grant:
   - **Display over other apps** (for Top Capsule)
   - **Modify system settings** (for brightness)
3. Go to **Settings → Accessibility → Installed apps → STUDIO BHARAT X** and **turn ON** the service.
4. Now Phone Agent actions run in **native** mode (not simulated).

## Local web preview

```bash
npm install
# put GEMINI_API_KEY in .env.local
npm run dev
```

In the browser everything still shows as **simulated** — that is expected. Real control only works inside the installed APK after Accessibility is enabled.

## Project structure (important)

```
android-native/
  VedaAgentPlugin.kt          ← Capacitor plugin (openApp, home, back, clickByText…)
  VedaAccessibilityService.kt ← AccessibilityService (gestures + node tree)
  TopCapsuleService.kt        ← floating overlay
  accessibility_service_config.xml

.github/workflows/build-apk.yml  ← now injects the native files + Manifest registration
src/services/phoneAgentService.ts
src/components/PhoneAgentRoom.tsx
```

## Secrets

Configure via the in-app **Secrets Panel**:
- Gemini / Groq / other AI keys
- Facebook Page ID + Page Access Token (for Reels publish)
- GitHub PAT (for export + Actions)

## Notes

- Voice / Gemini Live works in both web and APK.
- Facebook Reels publishing uses official Graph API v21 3-step flow.
- Video / Bhojpuri rooms generate assets; real device camera/mic needs the APK permissions already added in the workflow.
