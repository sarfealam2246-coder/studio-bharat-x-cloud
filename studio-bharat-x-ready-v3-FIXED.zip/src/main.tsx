import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

class StudioErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { error: Error | null }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  render() {
    if (this.state.error) {
      return (
        <div style={{ padding: 20, background: '#0A0B0E', color: '#F4F5F7', minHeight: '100vh', fontFamily: 'sans-serif' }}>
          <h2 style={{ color: '#F59E0B', marginBottom: 8 }}>STUDIO BHARAT X — Recovery</h2>
          <p style={{ fontSize: 13, color: '#CBD5E1', marginBottom: 12 }}>
            {this.state.error.message || 'Unexpected UI error'}
          </p>
          <button
            type="button"
            onClick={() => {
              this.setState({ error: null });
              window.location.reload();
            }}
            style={{ padding: '10px 16px', borderRadius: 12, background: '#F59E0B', color: '#0A0B0E', fontWeight: 700, border: 'none' }}
          >
            Reload Studio
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <StudioErrorBoundary>
    <App />
  </StudioErrorBoundary>
);
