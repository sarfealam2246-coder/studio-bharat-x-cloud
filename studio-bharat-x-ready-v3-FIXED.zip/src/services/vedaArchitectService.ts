import {
  BhojpuriVedaCommandAction,
  DepartmentId,
  Language,
  LockedStepPlan,
  ResearchSource,
} from '../types/studio';
import { DEPARTMENT_META } from '../i18n/translations';
import { studioBus } from './eventBus';

/**
 * Normalizes common broken Hindi/Hinglish voice-to-text transcriptions
 * into accurate technical terms before routing or prompting the AI Brain.
 */
export function normalizeBrokenSttTranscript(raw: string): string {
  const replacements: Array<[RegExp, string]> = [
    [/इन\s*मीडिया|एन\s*वीडिया|एनवीडिया/gi, 'NVIDIA'],
    [/ग्रोक|ग्रो\s*एपीआई|ग्रो\s*की|ग्रो\s*मॉडल/gi, 'Groq'],
    [/सिगरेट\s*(वॉल्ट|पैनल|सेटिंग|कुंजी|की)?/gi, 'Secrets $1'],
    [/अमल\s*(फ़ाइल|फाइल|कॉन्फ़िग|कोड)?/gi, 'YAML $1'],
    [/गिठब|गिट\s*हब/gi, 'GitHub'],
    [/क्लाउड\s*फ्लेयर/gi, 'Cloudflare'],
    [/जेमिनी/gi, 'Gemini'],
  ];

  let out = raw;
  for (const [pattern, target] of replacements) {
    out = out.replace(pattern, target);
  }
  return out.replace(/\s+/g, ' ').trim();
}

export interface ArchitectIntentAnalysis {
  normalizedText: string;
  wantsStepPlan: boolean;
  ambiguousBuild: boolean;
  clarifyRooms?: DepartmentId[];
  clarifyQuestion?: string;
  directDepartment?: DepartmentId;
  shouldAutoSwitchRoom: boolean;
  directModal?: 'secrets' | 'projects' | 'memory';
  planDepartmentHint: DepartmentId;
}

export interface BhojpuriVedaCommandMatch {
  action: BhojpuriVedaCommandAction;
  topic?: string;
}

/**
 * Detects direct VEDA voice/text commands for the Bhojpuri Reels pipeline:
 * 1. Facebook Page Publish
 * 2. 24/7 Cloud FFmpeg Render
 * 3. Live Bhojpuri Comedy Story Research
 */
export function detectBhojpuriVedaCommand(normalizedText: string): BhojpuriVedaCommandMatch | null {
  const q = normalizedText.toLowerCase();

  // 1. Facebook Publish command
  const mentionsFb = /(facebook|fb\s*page|meta\s*reel|फेसबुक)/i.test(q);
  const mentionsPublish = /(publish|post|upload|share|daal|dal|पब्लिश|पोस्ट|अपलोड|डालो)/i.test(q);
  if (mentionsFb && mentionsPublish) {
    return { action: 'facebook_publish' };
  }

  // 2. Cloud FFmpeg Render command
  const mentionsCloudRender =
    /(cloud\s*(ffmpeg\s*)?render|ffmpeg\s*render|render\s*(bhojpuri|reel|video|mp4)|क्लाउड\s*रेंडर|रेंडर\s*(करो|चलाओ|शुरू))/i.test(
      q
    );
  if (mentionsCloudRender) {
    return { action: 'cloud_render' };
  }

  // 3. Bhojpuri Story Research & Creation command
  const mentionsBhojpuri = /(bhojpuri|भोजपुरी)/i.test(q);
  const mentionsStoryOrResearch =
    /(research|story|comedy|script|reel\s*banao|naya\s*reel|story\s*banao|रिसर्च|कहानी|स्टोरी|कॉमेडी|स्क्रिप्ट|रील\s*बनाओ)/i.test(
      q
    );
  if (mentionsBhojpuri && mentionsStoryOrResearch) {
    const topicMatch = normalizedText.match(/(?:on|about|topic|पर|विषय)\s+(.{3,60})$/i);
    return {
      action: 'research',
      topic: topicMatch?.[1]?.trim(),
    };
  }

  return null;
}

const STEP_PLAN_REGEX =
  /\b(steps?\s*banao|plan\s*lock|lock\s*plan|locked\s*steps?|step[- ]by[- ]step|roadmap|architecture\s*plan|blueprint)\b|(स्टेप्स\s*बनाओ|प्लान\s*लॉक|योजना\s*बनाओ|कदम\s*दर\s*कदम)/i;

const BUILD_ACTION_REGEX =
  /\b(build|create|make|start|open|switch|launch|go to|enter|banao|banana|kholo|khol|chalu|shuru)\b|(बनाओ|बनाना|खोलो|खोलूँ|खोल|शुरू|चलाओ)/i;

export function analyzeVedaArchitectIntent(
  rawInput: string,
  language: Language
): ArchitectIntentAnalysis {
  const normalizedText = normalizeBrokenSttTranscript(rawInput);
  const q = normalizedText.toLowerCase();

  const wantsStepPlan = STEP_PLAN_REGEX.test(normalizedText);

  const mentionsGaming = /(game|gaming|3d\s*game|2d\s*game|shooter|racing|unity|canvas\s*game|गेम|गेमिंग)/i.test(
    q
  );
  const mentionsApps =
    /(commercial\s*app|mobile\s*app|web\s*app|saas|ecommerce|store\s*app|dashboard|website|ऐप|ऐप्स|कमर्शियल|वेबसाइट)/i.test(
      q
    );
  const mentionsBhojpuri = /(bhojpuri|reel|reels|short\s*video|भोजपुरी|रील|रील्स)/i.test(q);
  const mentionsAgent =
    /(phone\s*agent|automate\s*(my\s*)?phone|device\s*agent|whatsapp\s*bot|phone\s*automation|फ़ोन\s*एजेंट|फोन\s*एजेंट|ऑटोमेट)/i.test(
      q
    );

  const matchedDepartments: DepartmentId[] = [];
  if (mentionsGaming) matchedDepartments.push('gaming');
  if (mentionsApps) matchedDepartments.push('apps');
  if (mentionsBhojpuri) matchedDepartments.push('bhojpuri');
  if (mentionsAgent) matchedDepartments.push('agent');

  const isBuildOrOpen = BUILD_ACTION_REGEX.test(normalizedText);
  const isVagueBuild =
    isBuildOrOpen &&
    matchedDepartments.length === 0 &&
    /(naya\s*project|something|kuch\s*naya|project\s*banao|नया\s*प्रोजेक्ट|कुछ\s*नया|प्रोजेक्ट\s*बनाओ)/i.test(
      q
    );

  // Ambiguous: user mentions both gaming and apps OR gives a vague "build something new" request
  if (!wantsStepPlan && ((mentionsGaming && mentionsApps) || isVagueBuild)) {
    const clarifyRooms: DepartmentId[] =
      mentionsGaming && mentionsApps ? ['gaming', 'apps'] : ['gaming', 'apps', 'bhojpuri', 'agent'];
    const clarifyQuestion =
      language === 'hi'
        ? 'सर, गेमिंग खोलूँ या कमर्शियल ऐप?'
        : 'Should I open Gaming Studio or Commercial Apps?';

    return {
      normalizedText,
      wantsStepPlan: false,
      ambiguousBuild: true,
      clarifyRooms,
      clarifyQuestion,
      shouldAutoSwitchRoom: false,
      planDepartmentHint: 'apps',
    };
  }

  // Modal shortcuts (only when user clearly asks to open Secrets / Projects / Memory)
  if (!wantsStepPlan && /(open|show|खोलो|दिखाओ).*(secret|vault|api\s*key|सीक्रेट)/i.test(q)) {
    return {
      normalizedText,
      wantsStepPlan: false,
      ambiguousBuild: false,
      directModal: 'secrets',
      shouldAutoSwitchRoom: false,
      planDepartmentHint: 'apps',
    };
  }
  if (!wantsStepPlan && /(open|show|खोलो|दिखाओ).*(memory|मेमोरी)/i.test(q)) {
    return {
      normalizedText,
      wantsStepPlan: false,
      ambiguousBuild: false,
      directModal: 'memory',
      shouldAutoSwitchRoom: false,
      planDepartmentHint: 'apps',
    };
  }
  if (!wantsStepPlan && /(open|show|खोलो|दिखाओ).*(project|workspace|प्रोजेक्ट)/i.test(q)) {
    return {
      normalizedText,
      wantsStepPlan: false,
      ambiguousBuild: false,
      directModal: 'projects',
      shouldAutoSwitchRoom: false,
      planDepartmentHint: 'apps',
    };
  }

  const singleDepartment =
    matchedDepartments.length === 1 ? matchedDepartments[0] : undefined;

  // Auto-switch immediately when user explicitly asks to open/build in a single unambiguous department
  // (unless they asked for a step-by-step plan in VEDA first)
  const shouldAutoSwitchRoom = Boolean(singleDepartment && isBuildOrOpen && !wantsStepPlan);

  return {
    normalizedText,
    wantsStepPlan,
    ambiguousBuild: false,
    directDepartment: singleDepartment,
    shouldAutoSwitchRoom,
    planDepartmentHint: singleDepartment ?? 'apps',
  };
}

export function switchToDepartmentViaBus(department: DepartmentId, source = 'veda-architect'): void {
  studioBus.emit('room:change', { room: department, source });
}

export function buildLocalLockedStepPlan(
  userPrompt: string,
  department: DepartmentId,
  language: Language
): LockedStepPlan {
  const cleanTitle =
    userPrompt
      .replace(STEP_PLAN_REGEX, '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 64) || `${DEPARTMENT_META[department].shortLabel[language]} Blueprint`;

  const blueprints: Record<DepartmentId, Array<{ title: string; detail: string }>> = {
    gaming:
      language === 'hi'
        ? [
            {
              title: 'कोर गेम लूप और कंट्रोल्स लॉक करें',
              detail: 'प्लेयर मूवमेंट, कैमरा एंगल, स्कोरिंग और मोबाइल टच + कीबोर्ड कंट्रोल्स तय करें।',
            },
            {
              title: 'सीन आर्किटेक्चर और एसेट्स सेटअप',
              detail: 'scene.config.json में 16:9 कैनवास, FPS टारगेट, लाइटिंग और एसेट लिस्ट लॉक करें।',
            },
            {
              title: 'फ़िज़िक्स, कोलिज़न और HUD लेयर',
              detail: 'हिटबॉक्स, लेवल प्रोग्रेशन, हेल्थ/स्कोर HUD और पॉज़/रीस्टार्ट स्टेट बनाएँ।',
            },
            {
              title: 'आइसोलेटेड गेमिंग स्टेज वेरिफिकेशन',
              detail: 'गेमिंग रूम में Expand/Compact प्रीव्यू टेस्ट करें और IndexedDB में सेव करें।',
            },
          ]
        : [
            {
              title: 'Lock Core Game Loop & Controls',
              detail: 'Define player physics, win/loss conditions, touch controls, and camera framing.',
            },
            {
              title: 'Scene Architecture & Config Spec',
              detail: 'Structure 16:9 canvas settings, target FPS, and entity schemas in scene.config.json.',
            },
            {
              title: 'Collision, Scoring & HUD Layer',
              detail: 'Implement responsive HUD counters, level difficulty curves, and clean restart state.',
            },
            {
              title: 'Isolated Stage Verification',
              detail: 'Validate inside the isolated Gaming Room preview and persist build files to IndexedDB.',
            },
          ],
    apps:
      language === 'hi'
        ? [
            {
              title: 'स्क्रीन फ़्लो और डेटा मॉडल लॉक करें',
              detail: 'मुख्य स्क्रीन, यूज़र जर्नी और app.manifest.json में स्टेट स्कीमा तय करें।',
            },
            {
              title: '360px मोबाइल-फ़र्स्ट UI सिस्टम',
              detail: 'बिना ओवरफ़्लो के नेविगेशन, कार्ड ग्रिड, फ़ॉर्म और टच-फ़्रेंडली बटन बनाएँ।',
            },
            {
              title: 'बिज़नेस लॉजिक और लोकल/API स्टोरेज',
              detail: 'CRUD वर्कफ़्लो, फ़िल्टरिंग, वैलिडेशन और सुरक्षित डेटा सिंक जोड़ें।',
            },
            {
              title: 'कमर्शियल ऐप्स रूम में प्रीव्यू वेरिफाई करें',
              detail: 'आइसोलेटेड Apps स्टेज में पूरा फ़्लो जाँचकर IndexedDB में लॉक करें।',
            },
          ]
        : [
            {
              title: 'Lock Information Architecture & Data Model',
              detail: 'Map core user screens, entities, and state contracts in app.manifest.json.',
            },
            {
              title: '360px Mobile-First Responsive Layout',
              detail: 'Build zero-overflow navigation, cards, forms, and accessible touch targets.',
            },
            {
              title: 'Core Flows & Persistence Wiring',
              detail: 'Implement real interactive state, validation, search/filter, and storage sync.',
            },
            {
              title: 'Isolated Apps Room Verification',
              detail: 'Inspect in the dedicated Apps viewport stage and lock project files in IndexedDB.',
            },
          ],
    bhojpuri:
      language === 'hi'
        ? [
            {
              title: '0–3 सेकंड वायरल हुक और थीम लॉक करें',
              detail: 'भोजपुरी टोन, ओपनिंग डायलॉग और पहला विज़ुअल फ्रेम reel.storyboard.md में लिखें।',
            },
            {
              title: '9:16 सीन-बाय-सीन स्टोरीबोर्ड',
              detail: 'हर शॉट के लिए कैमरा एंगल, कैप्शन टाइमिंग और बैकग्राउंड बीट तय करें।',
            },
            {
              title: 'वॉइसओवर, लिरिक्स और टेक्स्ट ओवरले',
              detail: 'साफ़ देवनागरी/हिंग्लिश कैप्शन और रिदम के साथ अंतिम स्क्रिप्ट लॉक करें।',
            },
            {
              title: 'भोजपुरी रील्स स्टेज रिव्यू',
              detail: '9:16 आइसोलेटेड प्रीव्यू में स्टोरीबोर्ड और मेटाडेटा वेरिफाई करें।',
            },
          ]
        : [
            {
              title: 'Lock 0–3s Hook & Bhojpuri Theme',
              detail: 'Define opening punchline, hook visual, and music mood in reel.storyboard.md.',
            },
            {
              title: '9:16 Shot-by-Shot Storyboard',
              detail: 'Map exact visual cuts, pacing beats, and on-screen caption cues.',
            },
            {
              title: 'Dialogue, Captions & Audio Sync',
              detail: 'Finalize Bhojpuri script timing, callout typography, and reel.meta.json specs.',
            },
            {
              title: 'Isolated Reels Stage Review',
              detail: 'Verify vertical 9:16 framing inside the Bhojpuri Room and save to IndexedDB.',
            },
          ],
    agent:
      language === 'hi'
        ? [
            {
              title: 'ट्रिगर और लक्ष्य कार्य लॉक करें',
              detail: 'फ़ोन एजेंट का सटीक ट्रिगर, इनपुट पैरामीटर और अपेक्षित आउटपुट तय करें।',
            },
            {
              title: 'स्टेप-बाय-स्टेप ऑटोमेशन ग्राफ़',
              detail: 'agent.workflow.json में स्क्रीन इंस्पेक्शन, एक्शन सीक्वेंस और एरर हैंडलिंग लिखें।',
            },
            {
              title: 'सेफ़्टी गार्डरेल्स और यूज़र कन्फ़र्मेशन',
              detail: 'संवेदनशील स्टेप्स से पहले अनिवार्य यूज़र अनुमति और रोलबैक नियम जोड़ें।',
            },
            {
              title: 'आइसोलेटेड एजेंट स्टेज टेस्टिंग',
              detail: 'फ़ोन एजेंट कक्ष में वर्कफ़्लो स्पेक्स जाँचकर IndexedDB में सेव करें।',
            },
          ]
        : [
            {
              title: 'Lock Automation Trigger & Goal',
              detail: 'Specify exact trigger conditions, target app/service, and completion criteria.',
            },
            {
              title: 'Deterministic Action Sequence',
              detail: 'Define ordered workflow nodes, retries, and fallback rules in agent.workflow.json.',
            },
            {
              title: 'Safety Guardrails & Confirmation Gates',
              detail: 'Require explicit user approval before destructive or external-facing actions.',
            },
            {
              title: 'Isolated Agent Room Validation',
              detail: 'Review structured plan in the Phone Agent stage and lock files in IndexedDB.',
            },
          ],
  };

  return {
    id: `plan_${Date.now().toString(36)}`,
    title: cleanTitle,
    department,
    createdAt: Date.now(),
    steps: blueprints[department].map((s, idx) => ({
      stepNumber: idx + 1,
      title: s.title,
      detail: s.detail,
    })),
  };
}

export function formatLockedPlanMarkdown(plan: LockedStepPlan): string {
  const lines = [
    `# ${plan.title}`,
    `Department: ${plan.department}`,
    `Locked At: ${new Date(plan.createdAt).toLocaleString()}`,
    '',
    ...plan.steps.map(
      (s) => `## Step ${s.stepNumber}: ${s.title}\n${s.detail}\n`
    ),
  ];
  return lines.join('\n');
}

export function buildNonBlockingOfflineReply(params: {
  language: Language;
  noKeysConfigured: boolean;
  findings: ResearchSource[];
  directDepartment?: DepartmentId;
  wantsStepPlan: boolean;
}): string {
  const { language, noKeysConfigured, findings, directDepartment, wantsStepPlan } = params;

  if (findings.length > 0) {
    const bulletLines = findings
      .slice(0, 4)
      .map((f, idx) => `${idx + 1}. **${f.title}** (${f.provider}): ${f.snippet}`)
      .join('\n');
    const tail = noKeysConfigured
      ? language === 'hi'
        ? '\n\n(पूर्ण AI विश्लेषण के लिए 🔑 Secrets में कोई भी Gemini, Groq, NVIDIA या OpenRouter कुंजी जोड़ें।)'
        : '\n\n(Add any Gemini, Groq, NVIDIA, or OpenRouter key in 🔑 Secrets for full AI synthesis.)'
      : '';
    return `${
      language === 'hi' ? 'लाइव वेब रिसर्च से ये सत्यापित परिणाम मिले हैं:\n\n' : 'Live web research returned these verified findings:\n\n'
    }${bulletLines}${tail}`;
  }

  if (wantsStepPlan) {
    return language === 'hi'
      ? 'आपका स्टेप-बाय-स्टेप प्लान लॉक कर दिया गया है। आप इसे कॉपी कर सकते हैं या सीधे संबंधित विभाग में भेज सकते हैं।'
      : 'Your step-by-step project plan is locked below. You can copy it or send it straight into the target department room.';
  }

  if (directDepartment) {
    const label = DEPARTMENT_META[directDepartment].cardTitle[language];
    return language === 'hi'
      ? `${label} कक्ष में स्विच किया जा रहा है। हर विभाग का अपना अलग प्रीव्यू स्टेज सुरक्षित है।`
      : `Switching into ${label}. Its isolated preview stage and IndexedDB workspace are ready.`;
  }

  if (noKeysConfigured) {
    return language === 'hi'
      ? 'VEDA AI Brain सक्रिय करने के लिए ऊपर 🔑 Secrets में कोई भी Gemini (1–3), Groq, NVIDIA NIM, Cloudflare या OpenRouter कुंजी जोड़ें — या अपनी कुंजी सीधे यहाँ चैट में पेस्ट कर दें।'
      : 'Add any Gemini (1–3), Groq, NVIDIA NIM, Cloudflare, or OpenRouter key in 🔑 Secrets — or paste a single API key directly here in chat to auto-configure VEDA Brain.';
  }

  return language === 'hi'
    ? 'अभी सभी कॉन्फ़िगर की गई AI कुंजियाँ व्यस्त हैं या टाइमआउट हुई हैं। कृपया कुछ सेकंड बाद फिर प्रयास करें या 🔑 Secrets में टेस्ट करें।'
    : 'All configured AI provider keys are currently busy or timed out. Retry shortly or run Test & Connect All in 🔑 Secrets.';
}
