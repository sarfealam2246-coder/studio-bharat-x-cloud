import { runVedaAiRouter } from './aiRouter';
import { runLiveWebResearch } from './liveWebResearchService';
import { createNewProjectFile, createProject, saveProject } from './projectStoreService';
import { Language, ResearchSource, StudioProject } from '../types/studio';

const AGENT_SETTINGS_KEY = 'studio_bharat_x_agent_v1';

export interface PhoneAgentSettings {
  topCapsuleEnabled: boolean;
  backgroundVoiceEnabled: boolean;
  screenReaderEnabled: boolean;
  lastBrightness: number;
}

export interface AgentActionLog {
  id: string;
  action: string;
  detail: string;
  mode: 'native' | 'simulated';
  timestamp: number;
}

export interface AgentLiveBriefResult {
  ok: boolean;
  topicLabel: string;
  summary: string;
  sources: ResearchSource[];
  providerUsed?: string;
}

interface VedaAgentNativePlugin {
  toggleTopCapsule?: (opts: { enabled: boolean }) => Promise<{ ok?: boolean; detail?: string }>;
  openApp?: (opts: { packageOrName: string }) => Promise<{ ok?: boolean; detail?: string }>;
  performSwipe?: (opts: { direction: 'up' | 'down' }) => Promise<{ ok?: boolean }>;
  performGlobalAction?: (opts: { action: string }) => Promise<{ ok?: boolean; action?: string; detail?: string }>;
  clickByText?: (opts: { text: string }) => Promise<{ ok?: boolean; detail?: string }>;
  tapAt?: (opts: { xPercent: number; yPercent: number }) => Promise<{ ok?: boolean }>;
  readScreen?: () => Promise<{ ok?: boolean; text?: string }>;
  setBrightness?: (opts: { level: number }) => Promise<{ ok?: boolean }>;
  isAccessibilityEnabled?: () => Promise<{ ok?: boolean; enabled?: boolean }>;
}

function getNativeAgentPlugin(): VedaAgentNativePlugin | null {
  if (typeof window === 'undefined') return null;
  const cap = (
    window as unknown as {
      Capacitor?: { Plugins?: { VedaAgent?: VedaAgentNativePlugin } };
    }
  ).Capacitor;
  return cap?.Plugins?.VedaAgent ?? null;
}

export function loadPhoneAgentSettings(): PhoneAgentSettings {
  try {
    const raw = window.localStorage.getItem(AGENT_SETTINGS_KEY);
    if (!raw) {
      return {
        topCapsuleEnabled: false,
        backgroundVoiceEnabled: false,
        screenReaderEnabled: true,
        lastBrightness: 75,
      };
    }
    const parsed = JSON.parse(raw) as Partial<PhoneAgentSettings>;
    return {
      topCapsuleEnabled: Boolean(parsed.topCapsuleEnabled),
      backgroundVoiceEnabled: Boolean(parsed.backgroundVoiceEnabled),
      screenReaderEnabled: parsed.screenReaderEnabled ?? true,
      lastBrightness: typeof parsed.lastBrightness === 'number' ? parsed.lastBrightness : 75,
    };
  } catch {
    return {
      topCapsuleEnabled: false,
      backgroundVoiceEnabled: false,
      screenReaderEnabled: true,
      lastBrightness: 75,
    };
  }
}

export function savePhoneAgentSettings(settings: PhoneAgentSettings): void {
  try {
    window.localStorage.setItem(AGENT_SETTINGS_KEY, JSON.stringify(settings));
  } catch {
    // ignore storage quota errors
  }
}

export async function toggleNativeTopCapsule(enabled: boolean): Promise<'native' | 'simulated'> {
  const plugin = getNativeAgentPlugin();
  if (plugin?.toggleTopCapsule) {
    try {
      await plugin.toggleTopCapsule({ enabled });
      return 'native';
    } catch {
      // fall back cleanly
    }
  }
  return 'simulated';
}

export async function executePhoneAgentAction(
  actionType:
    | 'open_app'
    | 'swipe_up'
    | 'swipe_down'
    | 'read_screen'
    | 'brightness'
    | 'home'
    | 'back'
    | 'recents'
    | 'click_text'
    | 'tap',
  language: Language,
  param?: string
): Promise<AgentActionLog> {
  const plugin = getNativeAgentPlugin();
  const now = Date.now();

  if (actionType === 'open_app') {
    const target = (param || 'YouTube').trim();
    if (plugin?.openApp) {
      try {
        const res = await plugin.openApp({ packageOrName: target });
        return {
          id: `act-${now}`,
          action: `Open ${target}`,
          detail: res.detail || `${target} launched via Android Accessibility Bridge.`,
          mode: 'native',
          timestamp: now,
        };
      } catch {
        // fallback
      }
    }
    return {
      id: `act-${now}`,
      action: `Open ${target}`,
      detail:
        language === 'hi'
          ? `ब्राउज़र प्रीव्यू: असली APK में ${target} Android Accessibility से खुल जाएगा।`
          : `Preview simulation: ${target} launches via VedaAccessibilityService in Android APK.`,
      mode: 'simulated',
      timestamp: now,
    };
  }

  if (actionType === 'swipe_up' || actionType === 'swipe_down') {
    const direction = actionType === 'swipe_down' ? 'down' : 'up';
    if (plugin?.performSwipe) {
      try {
        await plugin.performSwipe({ direction });
        return {
          id: `act-${now}`,
          action: direction === 'down' ? 'Swipe Down' : 'Swipe Up',
          detail: `Performed ${direction} gesture via AccessibilityService.`,
          mode: 'native',
          timestamp: now,
        };
      } catch {
        // fallback
      }
    }
    return {
      id: `act-${now}`,
      action: direction === 'down' ? 'Swipe Down' : 'Swipe Up',
      detail:
        language === 'hi'
          ? `प्रीव्यू सिमुलेशन: APK में ${direction === 'down' ? 'नीचे' : 'ऊपर'} स्वाइप जेस्चर चलेगा।`
          : `Preview simulation: ${direction} swipe gesture queued for Android Accessibility.`,
      mode: 'simulated',
      timestamp: now,
    };
  }

  if (actionType === 'home' || actionType === 'back' || actionType === 'recents') {
    if (plugin?.performGlobalAction) {
      try {
        const res = await plugin.performGlobalAction({ action: actionType });
        return {
          id: `act-${now}`,
          action: actionType.toUpperCase(),
          detail: res.ok
            ? `Global action "${actionType}" performed.`
            : `Global action "${actionType}" failed — enable Accessibility Service.`,
          mode: 'native',
          timestamp: now,
        };
      } catch {
        // fallback
      }
    }
    return {
      id: `act-${now}`,
      action: actionType.toUpperCase(),
      detail:
        language === 'hi'
          ? `प्रीव्यू: APK में ${actionType} बटन दबाया जाएगा (Accessibility Service चालू होना चाहिए)।`
          : `Preview: ${actionType} global action will run in APK when Accessibility Service is enabled.`,
      mode: 'simulated',
      timestamp: now,
    };
  }

  if (actionType === 'click_text') {
    const targetText = (param || '').trim();
    if (plugin?.clickByText && targetText) {
      try {
        const res = await plugin.clickByText({ text: targetText });
        return {
          id: `act-${now}`,
          action: `Click "${targetText}"`,
          detail: res.detail || (res.ok ? 'Clicked' : 'Not found'),
          mode: 'native',
          timestamp: now,
        };
      } catch {
        // fallback
      }
    }
    return {
      id: `act-${now}`,
      action: `Click "${targetText || '?'}"`,
      detail:
        language === 'hi'
          ? `प्रीव्यू: APK में स्क्रीन पर "${targetText}" टेक्स्ट वाला बटन दबाया जाएगा।`
          : `Preview: will click on-screen element matching "${targetText}" in APK.`,
      mode: 'simulated',
      timestamp: now,
    };
  }

  if (actionType === 'tap') {
    // param format: "x,y" percentages
    const parts = (param || '50,50').split(',').map((p) => Number(p.trim()) || 50);
    const xPercent = Math.max(1, Math.min(99, parts[0] ?? 50));
    const yPercent = Math.max(1, Math.min(99, parts[1] ?? 50));
    if (plugin?.tapAt) {
      try {
        await plugin.tapAt({ xPercent, yPercent });
        return {
          id: `act-${now}`,
          action: `Tap ${xPercent}%,${yPercent}%`,
          detail: `Tapped at screen position ${xPercent}% x ${yPercent}%.`,
          mode: 'native',
          timestamp: now,
        };
      } catch {
        // fallback
      }
    }
    return {
      id: `act-${now}`,
      action: `Tap ${xPercent}%,${yPercent}%`,
      detail:
        language === 'hi'
          ? `प्रीव्यू: APK में स्क्रीन के ${xPercent}% x ${yPercent}% पर टैप होगा।`
          : `Preview: tap at ${xPercent}% x ${yPercent}% will run in APK.`,
      mode: 'simulated',
      timestamp: now,
    };
  }

  if (actionType === 'read_screen') {
    if (plugin?.readScreen) {
      try {
        const res = await plugin.readScreen();
        return {
          id: `act-${now}`,
          action: 'Read Screen',
          detail: res.text || 'Captured visible Android window text nodes.',
          mode: 'native',
          timestamp: now,
        };
      } catch {
        // fallback
      }
    }
    return {
      id: `act-${now}`,
      action: 'Read Screen',
      detail:
        language === 'hi'
          ? 'स्क्रीन रीडर तैयार: STUDIO BHARAT X सक्रिय है। APK में यह किसी भी ऐप की स्क्रीन पढ़कर सुनाएगा।'
          : 'Screen reader ready: STUDIO BHARAT X active. In Android APK, reads active foreground app nodes.',
      mode: 'simulated',
      timestamp: now,
    };
  }

  // brightness (default fall-through)
  const level = Math.max(10, Math.min(100, Number(param || 85) || 85));
  if (plugin?.setBrightness) {
    try {
      await plugin.setBrightness({ level });
      return {
        id: `act-${now}`,
        action: `Brightness ${level}%`,
        detail: `System brightness adjusted to ${level}%.`,
        mode: 'native',
        timestamp: now,
      };
    } catch {
      // fallback
    }
  }
  return {
    id: `act-${now}`,
    action: `Brightness ${level}%`,
    detail:
      language === 'hi'
        ? `ब्राइटनेस ${level}% पर सेट (APK में WRITE_SETTINGS से लागू होगा)।`
        : `Brightness set to ${level}% (applied via Android settings in APK).`,
    mode: 'simulated',
    timestamp: now,
  };
}

export async function runAgentLiveBrief(
  topic: 'news' | 'market' | 'youtube',
  language: Language
): Promise<AgentLiveBriefResult> {
  const queryMap = {
    news: 'India latest news today',
    market: 'Indian stock market Nifty Sensex',
    youtube: 'YouTube trending India viral shorts',
  };
  const labelMap = {
    news: language === 'hi' ? 'ताज़ा खबरें' : 'Latest News',
    market: language === 'hi' ? 'मार्केट अपडेट' : 'Market Movers',
    youtube: language === 'hi' ? 'YouTube ट्रेंड्स' : 'YouTube Trends',
  };

  const research = await runLiveWebResearch(queryMap[topic]);
  const prompt =
    language === 'hi'
      ? `${labelMap[topic]} पर ऊपर दिए गए ताज़ा वेब रिसर्च के आधार पर साफ़, सटीक और आसान हिंदी में मुख्य बातें संक्षेप में बताएं।`
      : `Summarize the key highlights for ${labelMap[topic]} clearly and concisely using the live web research findings.`;

  const ai = await runVedaAiRouter({
    userMessage: prompt,
    normalizedMessage: prompt,
    history: [],
    language,
    brainPreference: 'auto',
    researchContext: research.contextBlock,
  });

  return {
    ok: ai.ok,
    topicLabel: labelMap[topic],
    summary: ai.reply,
    sources: research.findings,
    providerUsed: ai.providerUsed,
  };
}

export function buildAndroidNativeBridgeFiles(): { path: string; content: string; language: string }[] {
  const accessibilityKt = `package com.studiobharatx.veda

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class VedaAccessibilityService : AccessibilityService() {
    companion object {
        var instance: VedaAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Observes active foreground app context when requested by VEDA
    }

    override fun onInterrupt() {}

    fun performSwipeUp(): Boolean {
        val dm = resources.displayMetrics
        val path = Path().apply {
            moveTo(dm.widthPixels / 2f, dm.heightPixels * 0.78f)
            lineTo(dm.widthPixels / 2f, dm.heightPixels * 0.24f)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 320)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun readVisibleText(): String {
        val root: AccessibilityNodeInfo = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null) return
            node.text?.let { if (it.isNotBlank()) sb.append(it).append(" | ") }
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        return sb.toString().take(1200)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }
}
`;

  const capsuleKt = `package com.studiobharatx.veda

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class TopCapsuleService : Service() {
    private var windowManager: WindowManager? = null
    private var capsuleView: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 72
        }

        capsuleView = TextView(this).apply {
            text = "VEDA ● Live"
            setPadding(28, 12, 28, 12)
            setTextColor(0xFFF59E0B.toInt())
            setBackgroundColor(0xE60A0B0E.toInt())
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(packageName)
                launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (launch != null) startActivity(launch)
            }
        }
        windowManager?.addView(capsuleView, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        capsuleView?.let { windowManager?.removeView(it) }
    }
}
`;

  return [
    { path: 'android-native/VedaAccessibilityService.kt', content: accessibilityKt, language: 'kotlin' },
    { path: 'android-native/TopCapsuleService.kt', content: capsuleKt, language: 'kotlin' },
  ];
}

export async function generateNativeFilesIntoAgentProject(
  existingProject: StudioProject | null
): Promise<StudioProject> {
  const target =
    existingProject && existingProject.department === 'agent'
      ? existingProject
      : await createProject({ name: 'VEDA Android Native Agent', department: 'agent' });

  const nativeFiles = buildAndroidNativeBridgeFiles();
  let nextFiles = [...target.files];
  for (const nf of nativeFiles) {
    const idx = nextFiles.findIndex((f) => f.path === nf.path);
    if (idx >= 0) {
      nextFiles[idx] = { ...nextFiles[idx], content: nf.content, updatedAt: Date.now() };
    } else {
      nextFiles.push(createNewProjectFile(nf.path, nf.content));
    }
  }

  const updated: StudioProject = { ...target, files: nextFiles, updatedAt: Date.now() };
  await saveProject(updated);
  return updated;
}
