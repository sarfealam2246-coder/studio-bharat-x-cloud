import { MemoryCategory, MemoryRule } from '../types/studio';

export const MEMORY_STORAGE_KEY = 'studio_bharat_x_memory_v1';
const MEMORY_DB_NAME = 'studio_bharat_x_memory_v1';
const MEMORY_STORE_NAME = 'rules';
const MEMORY_DB_VERSION = 1;

let memoryDbPromise: Promise<IDBDatabase | null> | null = null;

function generateMemoryId(): string {
  return `mem_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

function normalizeRuleKey(text: string): string {
  return text.toLowerCase().replace(/\s+/g, ' ').replace(/[.,!?;:।]+$/g, '').trim();
}

function readLocalMirror(): MemoryRule[] {
  try {
    const raw = window.localStorage.getItem(MEMORY_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is MemoryRule =>
        Boolean(item && typeof item.id === 'string' && typeof item.text === 'string')
    );
  } catch {
    return [];
  }
}

function writeLocalMirror(rules: MemoryRule[]): void {
  try {
    window.localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(rules));
  } catch {
    // Ignore storage write errors in restricted contexts.
  }
}

function openMemoryDb(): Promise<IDBDatabase | null> {
  if (typeof window === 'undefined' || !('indexedDB' in window)) {
    return Promise.resolve(null);
  }
  if (memoryDbPromise) return memoryDbPromise;

  memoryDbPromise = new Promise((resolve) => {
    try {
      const req = window.indexedDB.open(MEMORY_DB_NAME, MEMORY_DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(MEMORY_STORE_NAME)) {
          db.createObjectStore(MEMORY_STORE_NAME, { keyPath: 'id' });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
      req.onblocked = () => resolve(null);
    } catch {
      resolve(null);
    }
  });

  return memoryDbPromise;
}

async function syncAllToIndexedDb(rules: MemoryRule[]): Promise<void> {
  const db = await openMemoryDb();
  if (!db) return;
  await new Promise<void>((resolve) => {
    try {
      const tx = db.transaction(MEMORY_STORE_NAME, 'readwrite');
      const store = tx.objectStore(MEMORY_STORE_NAME);
      store.clear();
      for (const rule of rules) {
        store.put(rule);
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    } catch {
      resolve();
    }
  });
}

export async function listMemoryRules(): Promise<MemoryRule[]> {
  const localRules = readLocalMirror();
  const db = await openMemoryDb();
  if (!db) {
    return localRules.sort((a, b) => b.updatedAt - a.updatedAt);
  }

  const dbRules = await new Promise<MemoryRule[]>((resolve) => {
    try {
      const tx = db.transaction(MEMORY_STORE_NAME, 'readonly');
      const req = tx.objectStore(MEMORY_STORE_NAME).getAll();
      req.onsuccess = () =>
        resolve(Array.isArray(req.result) ? (req.result as MemoryRule[]) : []);
      req.onerror = () => resolve(localRules);
    } catch {
      resolve(localRules);
    }
  });

  // Merge without duplicates if localStorage had fresher entries
  const byKey = new Map<string, MemoryRule>();
  for (const rule of [...localRules, ...dbRules]) {
    const key = normalizeRuleKey(rule.text);
    const prev = byKey.get(key);
    if (!prev || rule.updatedAt > prev.updatedAt) {
      byKey.set(key, rule);
    }
  }
  const merged = Array.from(byKey.values()).sort((a, b) => b.updatedAt - a.updatedAt);
  writeLocalMirror(merged);
  return merged;
}

export function getActiveMemoryRulesSync(): MemoryRule[] {
  return readLocalMirror()
    .filter((r) => r.active && r.text.trim().length > 0)
    .sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function addMemoryRule(input: {
  text: string;
  category?: MemoryCategory;
  source?: 'manual' | 'auto';
}): Promise<{ saved: boolean; rule: MemoryRule | null; allRules: MemoryRule[] }> {
  const cleaned = input.text.trim().replace(/\s+/g, ' ');
  const existing = await listMemoryRules();
  if (cleaned.length < 3) {
    return { saved: false, rule: null, allRules: existing };
  }

  const targetKey = normalizeRuleKey(cleaned);
  const duplicate = existing.find((r) => normalizeRuleKey(r.text) === targetKey);
  if (duplicate) {
    return { saved: false, rule: duplicate, allRules: existing };
  }

  const now = Date.now();
  const newRule: MemoryRule = {
    id: generateMemoryId(),
    text: cleaned.slice(0, 260),
    category: input.category ?? 'preference',
    source: input.source ?? 'manual',
    active: true,
    createdAt: now,
    updatedAt: now,
  };

  const next = [newRule, ...existing];
  writeLocalMirror(next);
  await syncAllToIndexedDb(next);
  return { saved: true, rule: newRule, allRules: next };
}

export async function toggleMemoryRule(id: string): Promise<MemoryRule[]> {
  const existing = await listMemoryRules();
  const now = Date.now();
  const next = existing.map((r) =>
    r.id === id ? { ...r, active: !r.active, updatedAt: now } : r
  );
  writeLocalMirror(next);
  await syncAllToIndexedDb(next);
  return next;
}

export async function deleteMemoryRule(id: string): Promise<MemoryRule[]> {
  const existing = await listMemoryRules();
  const next = existing.filter((r) => r.id !== id);
  writeLocalMirror(next);
  await syncAllToIndexedDb(next);
  return next;
}

/**
 * Extracts explicit permanent user instructions/preferences from EN/HI/Hinglish chat text
 * (e.g. "याद रखना...", "remember that...", "yaad rakhna...", "my name is...", "always respond in...").
 */
export function extractExplicitMemoryFromMessage(message: string): string | null {
  const trimmed = message.trim();
  if (!trimmed || trimmed.length < 6) return null;

  const patterns: RegExp[] = [
    /(?:हमेशा\s+)?याद\s+रख(?:ना|ो|िए)(?:\s+कि)?\s*[:,-]?\s*(.+)/i,
    /(?:hamesha\s+)?yaad\s+rakh(?:na|o)(?:\s+ki)?\s*[:,-]?\s*(.+)/i,
    /(?:always\s+)?remember(?:\s+that)?\s*[:,-]?\s*(.+)/i,
    /from\s+now\s+on\s*[,:-]?\s*(.+)/i,
    /मेरा\s+नाम\s+([^\n.।!?]{2,40})/i,
    /my\s+name\s+is\s+([^\n.!?]{2,40})/i,
  ];

  for (const regex of patterns) {
    const match = trimmed.match(regex);
    if (match) {
      if (regex.source.startsWith('मेरा') || regex.source.startsWith('my\\s+name')) {
        return `User's name is ${match[1].trim()}`;
      }
      const candidate = match[1]?.trim();
      if (candidate && candidate.length >= 4) {
        return candidate;
      }
    }
  }
  return null;
}

export function buildMemoryPromptContext(rules?: MemoryRule[]): string {
  const active = (rules ?? getActiveMemoryRulesSync()).filter((r) => r.active);
  if (active.length === 0) return '';
  const lines = active
    .slice(0, 20)
    .map((r, idx) => `${idx + 1}. [${r.category}] ${r.text}`)
    .join('\n');
  return `PERMANENT USER MEMORY & PREFERENCES (ALWAYS HONOR THESE):\n${lines}`;
}
