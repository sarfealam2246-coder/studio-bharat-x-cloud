import { Language, LiveSessionStatus, VoicePersona } from '../types/studio';
import { studioBus } from './eventBus';
import { loadSecretsVault } from './secretsService';

const LIVE_MODEL = 'models/gemini-3.8-live';
const INPUT_SAMPLE_RATE = 16_000;
const OUTPUT_SAMPLE_RATE = 24_000;
const HANDSHAKE_TIMEOUT_MS = 6_000;
const KEY_COOLDOWN_MS = 45_000;

export interface LiveSessionOptions {
  persona?: VoicePersona;
  language?: Language;
  onStatusChange?: (status: LiveSessionStatus, keySlot?: number, detail?: string) => void;
  onTranscript?: (role: 'user' | 'veda', text: string) => void;
  onToolCall?: (name: string, args: Record<string, unknown>) => Promise<Record<string, unknown>>;
}

interface LiveKeySlot {
  slotIndex: number; // 0..2 -> Gemini Key 1..3
  apiKey: string;
}

const liveKeyCooldownUntil = new Map<number, number>();
let liveRoundRobinCursor = 0;

let status: LiveSessionStatus = 'idle';
let activeKeySlot: number | undefined;
let sessionToken = 0;
let intentionalClose = false;
let lastMicReleaseAt = 0;

let ws: WebSocket | null = null;
let micStream: MediaStream | null = null;
let inputAudioCtx: AudioContext | null = null;
let inputSourceNode: MediaStreamAudioSourceNode | null = null;
let inputProcessorNode: ScriptProcessorNode | null = null;

let outputAudioCtx: AudioContext | null = null;
let nextOutputStartTime = 0;
const scheduledOutputNodes = new Set<AudioBufferSourceNode>();

let currentOptions: LiveSessionOptions | null = null;
let activeSlotsAttempted = new Set<number>();

function setStatus(next: LiveSessionStatus, slot?: number, detail?: string): void {
  status = next;
  activeKeySlot = slot;
  currentOptions?.onStatusChange?.(next, slot, detail);
  studioBus.emit('voice:liveStatus', { status: next, keySlot: slot, detail });
}

function getAvailableLiveSlots(): LiveKeySlot[] {
  const vault = loadSecretsVault();
  const configured: LiveKeySlot[] = [];
  vault.geminiKeys.forEach((raw, idx) => {
    const trimmed = raw.trim();
    if (trimmed) {
      configured.push({ slotIndex: idx, apiKey: trimmed });
    }
  });
  if (configured.length === 0) return [];

  const start = liveRoundRobinCursor % configured.length;
  liveRoundRobinCursor = (liveRoundRobinCursor + 1) % configured.length;
  const rotated = [...configured.slice(start), ...configured.slice(0, start)];

  const now = Date.now();
  return rotated.filter((slot) => {
    if (activeSlotsAttempted.has(slot.slotIndex)) return false;
    const cooldown = liveKeyCooldownUntil.get(slot.slotIndex) ?? 0;
    return now >= cooldown;
  });
}

function markLiveKeyCooldown(slotIndex: number): void {
  liveKeyCooldownUntil.set(slotIndex, Date.now() + KEY_COOLDOWN_MS);
}

function downsampleTo16kPcmBase64(input: Float32Array, sourceRate: number): string {
  let samples: Float32Array;
  if (sourceRate === INPUT_SAMPLE_RATE) {
    samples = input;
  } else {
    const ratio = sourceRate / INPUT_SAMPLE_RATE;
    const targetLen = Math.max(1, Math.floor(input.length / ratio));
    samples = new Float32Array(targetLen);
    for (let i = 0; i < targetLen; i++) {
      const start = Math.floor(i * ratio);
      const end = Math.min(input.length, Math.floor((i + 1) * ratio));
      let sum = 0;
      let count = 0;
      for (let j = start; j < end; j++) {
        sum += input[j];
        count += 1;
      }
      samples[i] = count > 0 ? sum / count : input[start] ?? 0;
    }
  }

  const pcm16 = new Int16Array(samples.length);
  for (let i = 0; i < samples.length; i++) {
    const clamped = Math.max(-1, Math.min(1, samples[i]));
    pcm16[i] = clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff;
  }

  const bytes = new Uint8Array(pcm16.buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const slice = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
    binary += String.fromCharCode(...slice);
  }
  return window.btoa(binary);
}

function clearScheduledOutputAudio(): void {
  for (const node of Array.from(scheduledOutputNodes)) {
    try {
      node.onended = null;
      node.stop();
      node.disconnect();
    } catch {
      // Ignore already-stopped nodes.
    }
    scheduledOutputNodes.delete(node);
  }
  if (outputAudioCtx) {
    nextOutputStartTime = outputAudioCtx.currentTime;
  } else {
    nextOutputStartTime = 0;
  }
}

function schedulePcm24kChunk(base64Pcm: string): void {
  if (!outputAudioCtx || outputAudioCtx.state === 'closed') {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    outputAudioCtx = new AudioCtx({ sampleRate: OUTPUT_SAMPLE_RATE });
    nextOutputStartTime = outputAudioCtx.currentTime;
  }

  if (outputAudioCtx.state === 'suspended') {
    void outputAudioCtx.resume();
  }

  const binary = window.atob(base64Pcm);
  const evenLen = binary.length - (binary.length % 2);
  const bytes = new Uint8Array(evenLen);
  for (let i = 0; i < evenLen; i++) {
    bytes[i] = binary.charCodeAt(i);
  }

  const sampleCount = evenLen / 2;
  if (sampleCount <= 0) return;

  const view = new DataView(bytes.buffer);
  const buffer = outputAudioCtx.createBuffer(1, sampleCount, OUTPUT_SAMPLE_RATE);
  const channel = buffer.getChannelData(0);
  for (let i = 0; i < sampleCount; i++) {
    channel[i] = view.getInt16(i * 2, true) / 32768;
  }

  const source = outputAudioCtx.createBufferSource();
  source.buffer = buffer;
  source.connect(outputAudioCtx.destination);

  const now = outputAudioCtx.currentTime;
  const startTime = Math.max(now + 0.01, nextOutputStartTime);
  nextOutputStartTime = startTime + buffer.duration;

  scheduledOutputNodes.add(source);
  source.onended = () => {
    scheduledOutputNodes.delete(source);
    try {
      source.disconnect();
    } catch {
      // Ignore disconnect errors.
    }
  };

  try {
    source.start(startTime);
  } catch {
    scheduledOutputNodes.delete(source);
  }
}

function teardownSocketOnly(): void {
  if (ws) {
    const socket = ws;
    ws = null;
    try {
      socket.onopen = null;
      socket.onmessage = null;
      socket.onerror = null;
      socket.onclose = null;
      if (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING) {
        socket.close(1000, 'studio_live_close');
      }
    } catch {
      // Ignore socket close errors.
    }
  }
}

function teardownAudioResources(): void {
  clearScheduledOutputAudio();

  if (inputProcessorNode) {
    try {
      inputProcessorNode.onaudioprocess = null;
      inputProcessorNode.disconnect();
    } catch {
      // Ignore disconnect errors.
    }
    inputProcessorNode = null;
  }

  if (inputSourceNode) {
    try {
      inputSourceNode.disconnect();
    } catch {
      // Ignore disconnect errors.
    }
    inputSourceNode = null;
  }

  if (micStream) {
    for (const track of micStream.getTracks()) {
      try {
        track.stop();
      } catch {
        // Ignore stop errors.
      }
    }
    micStream = null;
    lastMicReleaseAt = Date.now();
  }

  if (inputAudioCtx) {
    const ctx = inputAudioCtx;
    inputAudioCtx = null;
    if (ctx.state !== 'closed') {
      void ctx.close().catch(() => {});
    }
  }

  if (outputAudioCtx) {
    const ctx = outputAudioCtx;
    outputAudioCtx = null;
    nextOutputStartTime = 0;
    if (ctx.state !== 'closed') {
      void ctx.close().catch(() => {});
    }
  }
}

async function ensureMicCaptureRunning(token: number): Promise<boolean> {
  if (micStream && inputAudioCtx && inputProcessorNode) {
    if (inputAudioCtx.state === 'suspended') {
      await inputAudioCtx.resume();
    }
    return true;
  }

  if (!navigator.mediaDevices?.getUserMedia) {
    return false;
  }

  const stream = await navigator.mediaDevices.getUserMedia({
    audio: {
      channelCount: 1,
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
    },
  });

  if (token !== sessionToken || intentionalClose) {
    stream.getTracks().forEach((track) => track.stop());
    lastMicReleaseAt = Date.now();
    return false;
  }

  micStream = stream;

  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  inputAudioCtx = new AudioCtx({ sampleRate: INPUT_SAMPLE_RATE });
  if (inputAudioCtx.state === 'suspended') {
    await inputAudioCtx.resume();
  }

  inputSourceNode = inputAudioCtx.createMediaStreamSource(stream);
  inputProcessorNode = inputAudioCtx.createScriptProcessor(4096, 1, 1);

  inputProcessorNode.onaudioprocess = (event: AudioProcessingEvent) => {
    if (!ws || ws.readyState !== WebSocket.OPEN || status !== 'connected') return;
    const channelData = event.inputBuffer.getChannelData(0);
    const rate = inputAudioCtx?.sampleRate ?? INPUT_SAMPLE_RATE;
    const base64Pcm = downsampleTo16kPcmBase64(channelData, rate);
    try {
      ws.send(
        JSON.stringify({
          realtimeInput: {
            audio: {
              mimeType: 'audio/pcm;rate=16000',
              data: base64Pcm,
            },
          },
        })
      );
    } catch {
      // Socket closed mid-frame; onclose handles failover cleanly.
    }
  };

  inputSourceNode.connect(inputProcessorNode);
  inputProcessorNode.connect(inputAudioCtx.destination);
  return true;
}

function shouldRotateOnClose(code: number, reason: string): boolean {
  const lower = reason.toLowerCase();
  if (
    lower.includes('429') ||
    lower.includes('503') ||
    lower.includes('quota') ||
    lower.includes('resource_exhausted') ||
    lower.includes('overloaded') ||
    lower.includes('api key') ||
    lower.includes('permission')
  ) {
    return true;
  }
  return code !== 1000 && code !== 1001;
}

async function decodeWsPayload(data: unknown): Promise<Record<string, unknown> | null> {
  try {
    if (typeof data === 'string') {
      return JSON.parse(data) as Record<string, unknown>;
    }
    if (data instanceof Blob) {
      const text = await data.text();
      return JSON.parse(text) as Record<string, unknown>;
    }
    if (data instanceof ArrayBuffer) {
      const text = new TextDecoder().decode(data);
      return JSON.parse(text) as Record<string, unknown>;
    }
  } catch {
    return null;
  }
  return null;
}

function connectWithNextKey(token: number, isFailover: boolean): void {
  if (token !== sessionToken || intentionalClose) return;

  const remaining = getAvailableLiveSlots();
  if (remaining.length === 0) {
    teardownSocketOnly();
    teardownAudioResources();
    setStatus('idle');
    studioBus.emit('voice:notice', {
      message: 'Live voice keys busy or not configured — check 🔑 Secrets',
      level: 'warning',
    });
    return;
  }

  const slot = remaining[0];
  activeSlotsAttempted.add(slot.slotIndex);
  setStatus(isFailover ? 'reconnecting' : 'connecting', slot.slotIndex + 1);

  const wsUrl = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=${encodeURIComponent(slot.apiKey)}`;
  const socket = new WebSocket(wsUrl);
  ws = socket;

  let handshakeDone = false;
  let rotatedForThisSocket = false;

  const rotateNow = (cooldownCurrent: boolean) => {
    if (rotatedForThisSocket || token !== sessionToken || intentionalClose) return;
    rotatedForThisSocket = true;
    window.clearTimeout(handshakeTimer);
    if (cooldownCurrent) {
      markLiveKeyCooldown(slot.slotIndex);
    }
    teardownSocketOnly();
    connectWithNextKey(token, true);
  };

  const handshakeTimer = window.setTimeout(() => {
    if (!handshakeDone) {
      rotateNow(true);
    }
  }, HANDSHAKE_TIMEOUT_MS);

  socket.onopen = () => {
    if (token !== sessionToken || intentionalClose || ws !== socket) {
      socket.close(1000, 'stale');
      return;
    }

    const persona: VoicePersona = currentOptions?.persona ?? 'Aoede';
    const lang: Language = currentOptions?.language ?? 'en';
    const systemText = [
      'You are VEDA inside STUDIO BHARAT X, an autonomous mobile studio AI with REAL tools.',
      lang === 'hi'
        ? 'Respond warmly and naturally in Hindi, Hinglish, or Bhojpuri (matching the user).'
        : 'Respond warmly and naturally in crisp studio voice.',
      'NEVER say you lack internet access or cannot open panels/departments—ALWAYS call your declared tools instead!',
      'Phonetic voice-to-text guide: "cigarette" / "सिगरेट" = Secrets; "इन मीडिया" = NVIDIA; "ग्रो" = Groq.',
      'Use `live_web_research` for ANY news, market, trending, or Bhojpuri topic research.',
      'Use `open_studio_panel` for Secrets, Projects, Memory, or Admin/APK.',
      'Use `switch_department` for Gaming, Apps, Bhojpuri, or Agent.',
      'Use `build_studio_project` when asked to build a 3D game or commercial app.',
      'Use `trigger_bhojpuri_action` for Bhojpuri story research, cloud render, or Facebook publish.',
      'Use `phone_agent_action` for opening phone apps, swiping, reading screen, or brightness.',
    ].join(' ');

    const liveTools = [
      {
        functionDeclarations: [
          {
            name: 'open_studio_panel',
            description: 'Open a studio modal/panel such as secrets, projects, memory, or admin.',
            parameters: {
              type: 'OBJECT',
              properties: {
                panel: { type: 'STRING', description: 'One of: secrets, projects, memory, admin' },
              },
              required: ['panel'],
            },
          },
          {
            name: 'switch_department',
            description: 'Switch the active STUDIO BHARAT X room/department.',
            parameters: {
              type: 'OBJECT',
              properties: {
                department: { type: 'STRING', description: 'One of: veda, gaming, apps, bhojpuri, agent' },
              },
              required: ['department'],
            },
          },
          {
            name: 'live_web_research',
            description: 'Search live public web sources (Wikipedia, DuckDuckGo, GitHub) for today news, stock market, or trending Bhojpuri topics.',
            parameters: {
              type: 'OBJECT',
              properties: {
                query: { type: 'STRING', description: 'Search query in English or Hindi' },
              },
              required: ['query'],
            },
          },
          {
            name: 'build_studio_project',
            description: 'Build a 3D/2D game in Gaming room or commercial web/mobile app in Apps room.',
            parameters: {
              type: 'OBJECT',
              properties: {
                department: { type: 'STRING', description: 'gaming or apps' },
                prompt: { type: 'STRING', description: 'Detailed build instructions' },
              },
              required: ['department', 'prompt'],
            },
          },
          {
            name: 'trigger_bhojpuri_action',
            description: 'Run Bhojpuri Reels research/story, cloud FFmpeg render, or Facebook Page publish.',
            parameters: {
              type: 'OBJECT',
              properties: {
                action: { type: 'STRING', description: 'research, cloud_render, or publish' },
                topic: { type: 'STRING', description: 'Optional comedy topic' },
              },
              required: ['action'],
            },
          },
          {
            name: 'phone_agent_action',
            description: 'Run a phone automation action: open_app, swipe_up, read_screen, or brightness.',
            parameters: {
              type: 'OBJECT',
              properties: {
                actionType: { type: 'STRING', description: 'open_app, swipe_up, read_screen, or brightness' },
                param: { type: 'STRING', description: 'Optional app name or brightness level' },
              },
              required: ['actionType'],
            },
          },
        ],
      },
    ];

    socket.send(
      JSON.stringify({
        setup: {
          model: LIVE_MODEL,
          generationConfig: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: persona,
                },
              },
            },
          },
          systemInstruction: {
            parts: [{ text: systemText }],
          },
          tools: liveTools,
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
      })
    );
  };

  socket.onmessage = async (event: MessageEvent) => {
    if (token !== sessionToken || intentionalClose || ws !== socket) return;
    const msg = await decodeWsPayload(event.data);
    if (!msg) return;

    const toolCallMsg = msg.toolCall as
      | {
          functionCalls?: Array<{
            id?: string;
            name?: string;
            args?: Record<string, unknown>;
          }>;
        }
      | undefined;

    if (toolCallMsg?.functionCalls && toolCallMsg.functionCalls.length > 0) {
      const responses: Array<{
        id: string;
        name: string;
        response: Record<string, unknown>;
      }> = [];

      for (const call of toolCallMsg.functionCalls) {
        const fnName = call.name || '';
        const fnId = call.id || fnName;
        const fnArgs = call.args ?? {};
        let result: Record<string, unknown> = { ok: true };
        if (currentOptions?.onToolCall && fnName) {
          try {
            result = await currentOptions.onToolCall(fnName, fnArgs);
          } catch (err) {
            result = {
              ok: false,
              error: err instanceof Error ? err.message : 'Tool execution error',
            };
          }
        }
        responses.push({
          id: fnId,
          name: fnName,
          response: result,
        });
      }

      if (ws === socket && socket.readyState === WebSocket.OPEN) {
        socket.send(
          JSON.stringify({
            toolResponse: {
              functionResponses: responses,
            },
          })
        );
      }
      return;
    }

    if (msg.setupComplete && !handshakeDone) {
      handshakeDone = true;
      window.clearTimeout(handshakeTimer);
      try {
        const micOk = await ensureMicCaptureRunning(token);
        if (!micOk) {
          stopLiveSession();
          studioBus.emit('voice:notice', {
            message: 'Microphone permission unavailable for Live Voice',
            level: 'warning',
          });
          return;
        }
        setStatus('connected', slot.slotIndex + 1, `Gemini Key ${slot.slotIndex + 1}`);
      } catch {
        stopLiveSession();
        studioBus.emit('voice:notice', {
          message: 'Microphone access denied — Live Voice stopped',
          level: 'warning',
        });
      }
      return;
    }

    const serverContent = msg.serverContent as
      | {
          interrupted?: boolean;
          inputTranscription?: { text?: string };
          outputTranscription?: { text?: string };
          modelTurn?: {
            parts?: Array<{
              inlineData?: { data?: string; mimeType?: string };
            }>;
          };
        }
      | undefined;

    if (!serverContent) return;

    if (serverContent.interrupted) {
      clearScheduledOutputAudio();
    }

    if (serverContent.inputTranscription?.text) {
      currentOptions?.onTranscript?.('user', serverContent.inputTranscription.text);
    }

    if (serverContent.outputTranscription?.text) {
      currentOptions?.onTranscript?.('veda', serverContent.outputTranscription.text);
    }

    for (const part of serverContent.modelTurn?.parts ?? []) {
      if (part.inlineData?.data) {
        schedulePcm24kChunk(part.inlineData.data);
      }
    }
  };

  socket.onerror = () => {
    if (token !== sessionToken || intentionalClose || ws !== socket) return;
    rotateNow(true);
  };

  socket.onclose = (event: CloseEvent) => {
    window.clearTimeout(handshakeTimer);
    if (token !== sessionToken || intentionalClose) return;
    if (ws === socket) {
      ws = null;
    }

    if (!handshakeDone || shouldRotateOnClose(event.code, event.reason || '')) {
      rotateNow(true);
      return;
    }

    teardownAudioResources();
    setStatus('idle');
  };
}

export function isLiveSessionActive(): boolean {
  return status !== 'idle';
}

export function getLiveSessionStatus(): LiveSessionStatus {
  return status;
}

export function getLiveKeySlot(): number | undefined {
  return activeKeySlot;
}

export function getMsSinceLiveMicRelease(): number {
  if (micStream || status !== 'idle') return 0;
  if (lastMicReleaseAt === 0) return Number.POSITIVE_INFINITY;
  return Date.now() - lastMicReleaseAt;
}

export function startLiveSession(options: LiveSessionOptions = {}): void {
  // Always clean up any previous Live session cleanly first
  if (status !== 'idle') {
    stopLiveSession();
  }

  intentionalClose = false;
  sessionToken += 1;
  currentOptions = options;
  activeSlotsAttempted = new Set<number>();

  connectWithNextKey(sessionToken, false);
}

export function stopLiveSession(): void {
  intentionalClose = true;
  sessionToken += 1;
  activeSlotsAttempted.clear();
  teardownSocketOnly();
  teardownAudioResources();
  setStatus('idle');
  currentOptions = null;
}
