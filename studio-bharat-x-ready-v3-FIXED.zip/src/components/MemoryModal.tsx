import React, { useEffect, useState } from 'react';
import { Brain, Plus, Trash2, X } from 'lucide-react';
import { UI_COPY } from '../i18n/translations';
import {
  addMemoryRule,
  deleteMemoryRule,
  toggleMemoryRule,
} from '../services/memoryService';
import { Language, MemoryCategory, MemoryRule } from '../types/studio';

interface MemoryModalProps {
  isOpen: boolean;
  language: Language;
  rules: MemoryRule[];
  onRulesChange: (next: MemoryRule[]) => void;
  onClose: () => void;
}

const CATEGORIES: Array<{ id: MemoryCategory; label: string }> = [
  { id: 'preference', label: 'Preference' },
  { id: 'rule', label: 'Rule' },
  { id: 'pattern', label: 'Pattern' },
  { id: 'fact', label: 'Fact' },
];

export const MemoryModal: React.FC<MemoryModalProps> = ({
  isOpen,
  language,
  rules,
  onRulesChange,
  onClose,
}) => {
  const t = UI_COPY[language];
  const [draftText, setDraftText] = useState('');
  const [category, setCategory] = useState<MemoryCategory>('preference');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const activeCount = rules.filter((r) => r.active).length;

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!draftText.trim() || saving) return;
    setSaving(true);
    try {
      const result = await addMemoryRule({
        text: draftText.trim(),
        category,
        source: 'manual',
      });
      onRulesChange(result.allRules);
      setDraftText('');
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = async (id: string) => {
    const next = await toggleMemoryRule(id);
    onRulesChange(next);
  };

  const handleDelete = async (id: string) => {
    const next = await deleteMemoryRule(id);
    onRulesChange(next);
  };

  return (
    <div
      className="fixed inset-0 z-[58] flex items-end sm:items-center justify-center bg-black/75 p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="memory-modal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-xl max-h-[88dvh] flex flex-col rounded-t-2xl sm:rounded-2xl bg-[#111319] border border-white/10 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="shrink-0 flex items-center justify-between gap-3 px-4 py-3.5 border-b border-white/8 bg-[#141720]">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-amber-400 shrink-0" />
              <h2
                id="memory-modal-title"
                className="text-base font-semibold text-[#F4F5F7] truncate"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                {t.memoryTitle}
              </h2>
              <span className="text-xs text-[#8D94A3] tabular-nums">
                · {activeCount}/{rules.length}
              </span>
            </div>
            <p className="text-xs text-[#9BA1AE] mt-0.5 leading-snug">{t.memorySubtitle}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close memory modal"
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-[#9BA1AE] hover:text-white hover:bg-white/6 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Add Manual Rule Form */}
        <form
          onSubmit={handleAdd}
          className="shrink-0 p-3.5 border-b border-white/8 bg-[#13161E] space-y-2"
        >
          <input
            type="text"
            value={draftText}
            onChange={(e) => setDraftText(e.target.value)}
            placeholder={t.addMemoryPlaceholder}
            className="w-full h-10 px-3 rounded-xl bg-[#0A0B0E] border border-white/10 text-xs text-[#F4F5F7] placeholder:text-[#5F6676] focus:outline-none focus:border-amber-400/70"
          />
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1 overflow-x-auto">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategory(cat.id)}
                  className={`h-8 px-2.5 rounded-lg text-[11px] font-medium transition-colors whitespace-nowrap ${
                    category === cat.id
                      ? 'bg-amber-500/18 text-amber-300'
                      : 'text-[#9BA1AE] hover:text-white hover:bg-white/5'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
            <button
              type="submit"
              disabled={!draftText.trim() || saving}
              className="h-8 px-3.5 rounded-xl bg-amber-500 text-[#0A0B0E] text-xs font-semibold hover:bg-amber-400 disabled:opacity-40 transition-colors inline-flex items-center gap-1 whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              {t.addRule}
            </button>
          </div>
        </form>

        {/* Rules List */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll p-4 pb-safe">
          {rules.length === 0 ? (
            <div className="py-10 text-center">
              <p className="text-xs sm:text-sm text-[#8D94A3]">{t.emptyMemory}</p>
            </div>
          ) : (
            <div className="divide-y divide-white/8 border border-white/8 rounded-xl bg-[#0E1016] overflow-hidden">
              {rules.map((rule) => (
                <div
                  key={rule.id}
                  className="p-3 flex items-start justify-between gap-3 hover:bg-white/[0.02] transition-colors"
                >
                  <div className="min-w-0 flex-1 space-y-1">
                    <p
                      className={`text-xs sm:text-sm leading-relaxed break-words ${
                        rule.active ? 'text-[#F4F5F7]' : 'text-[#6E7585] line-through'
                      }`}
                    >
                      {rule.text}
                    </p>
                    <div className="flex items-center gap-1.5 text-[11px] text-[#7D8596]">
                      <span className="capitalize">{rule.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{rule.source === 'auto' ? 'Auto-learned' : 'Manual'}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleToggle(rule.id)}
                      aria-pressed={rule.active}
                      className={`h-8 px-2.5 rounded-lg text-[11px] font-medium transition-colors ${
                        rule.active
                          ? 'bg-emerald-500/16 text-emerald-300 border border-emerald-500/30'
                          : 'bg-white/5 text-[#8D94A3] border border-white/10'
                      }`}
                    >
                      {rule.active ? 'Active' : 'Paused'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(rule.id)}
                      aria-label="Delete memory rule"
                      className="h-8 w-8 flex items-center justify-center rounded-lg text-[#8D94A3] hover:text-rose-400 hover:bg-rose-500/10"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
