package com.studiobharatx.veda

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class VedaAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: VedaAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Observes foreground app context when VEDA requests it
    }

    override fun onInterrupt() {}

    /** Perform a vertical swipe (up or down) */
    fun performSwipe(direction: String): Boolean {
        val dm = resources.displayMetrics
        val midX = dm.widthPixels / 2f
        val startY: Float
        val endY: Float
        if (direction.equals("down", ignoreCase = true)) {
            startY = dm.heightPixels * 0.28f
            endY = dm.heightPixels * 0.78f
        } else {
            // default = up
            startY = dm.heightPixels * 0.78f
            endY = dm.heightPixels * 0.24f
        }
        val path = Path().apply {
            moveTo(midX, startY)
            lineTo(midX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 320)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /** Legacy helper used by older plugin calls */
    fun performSwipeUp(): Boolean = performSwipe("up")

    /** Global system actions */
    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun openQuickSettings(): Boolean = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    /** Read all visible text from the active window */
    fun readVisibleText(): String {
        val root: AccessibilityNodeInfo = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null) return
            node.text?.let { if (it.isNotBlank()) sb.append(it).append(" | ") }
            node.contentDescription?.let { if (it.isNotBlank()) sb.append(it).append(" | ") }
            for (i in 0 until node.childCount) walk(node.getChild(i))
        }
        walk(root)
        return sb.toString().take(2000)
    }

    /** Find a node whose text / contentDescription contains the query and click it */
    fun clickByText(query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = query.trim().lowercase()
        if (q.isEmpty()) return false

        fun findAndClick(node: AccessibilityNodeInfo?): Boolean {
            if (node == null) return false
            val text = (node.text?.toString() ?: "").lowercase()
            val desc = (node.contentDescription?.toString() ?: "").lowercase()
            if ((text.contains(q) || desc.contains(q)) && node.isClickable) {
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            // Also try parent if this node is not clickable but matches
            if ((text.contains(q) || desc.contains(q))) {
                var p = node.parent
                while (p != null) {
                    if (p.isClickable) {
                        val ok = p.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        p.recycle()
                        return ok
                    }
                    val next = p.parent
                    p.recycle()
                    p = next
                }
            }
            for (i in 0 until node.childCount) {
                if (findAndClick(node.getChild(i))) return true
            }
            return false
        }
        return findAndClick(root)
    }

    /** Tap at approximate screen percentage (0-100) */
    fun tapAtPercent(xPercent: Int, yPercent: Int): Boolean {
        val dm = resources.displayMetrics
        val x = (dm.widthPixels * (xPercent.coerceIn(1, 99) / 100f))
        val y = (dm.heightPixels * (yPercent.coerceIn(1, 99) / 100f))
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }
}
